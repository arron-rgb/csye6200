package edu.neu.csye6200;

/**
 * Driver class is ALWAYS the first class we create in CSYE6200
 * AND the Driver class will be the ONLY class to contain the
 * main() method.
 * 
 * A Java program ALWAYS begins execution in the main() method.
 * main() is called first.
 *  
 * @author dpeters
 *
 */

public class Driver {

	/**
	 * This is the Start of our Program
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Driver main()...");
		
		/**
		 * Use a simple class with 
		 * 1. static class data (program scope always available)
		 * 2. public acessor (every class has access)
		 */
		System.out.println(SimplePublicStaticPerson.name); // name to stdout
		System.out.println(SimplePublicStaticPerson.age); // age to stdout
		
		/**
		 * Use a simple class with
		 * 1. object instance data 
		 * 	(every object has it's own data but must create object)  
		 * 2. public acessor (every class has access)
		 */
		/*
		 *  create Person object using default Person class constructor 
		 */
		SimplePubicPerson simplePublicPersonObject = new SimplePubicPerson(); // create object
		System.out.println(simplePublicPersonObject.name);	// name to stdout
		System.out.println(simplePublicPersonObject.age);	// age to stdout

		Person.demo(); 	// use Encapsulated Person class
		
		System.out.println("Driver main()... done!");
	}
}
