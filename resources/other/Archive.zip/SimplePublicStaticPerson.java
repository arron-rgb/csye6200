package edu.neu.csye6200;

/**
 * Person class is used to model a person.
 * 
 * @author dpeters
 *
 */
public class SimplePublicStaticPerson {
	/**
	 * Class members are specified inside the curly braces of the class
	 */
	/**
	 * Class (static) Data Members
	 */
	public static int age = 17;	// integer age
	public static String name = "Dan";	// String name
}
