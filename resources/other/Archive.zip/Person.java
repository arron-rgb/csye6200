package edu.neu.csye6200;

/**
 * Person class is used to model a person.
 * 
 * This class uses Abstraction and Encapsulation:
 * 	All data AND Methods which operate on the data is contained ONLY in this class
 * This means:
 * 	1. all data is PRIVATE so no other class can directly access it.
 *  2. public methods are ALSO in this class SO OTHER classes can use this class.
 * 
 * Abstraction is used here with private data to provide data hiding.
 * 
 * @author dpeters
 *
 */
public class Person {
	/**
	 * Object instance data
	 * 1. Does not exist until object is created
	 * 2. Each created object has its own data
	 */
	/**
	 * Private data supports Encapsulation
	 * Private data provides Abstraction, data hiding, no other class can access
	 */
	private int age;
	private String name;

	/**
	 * Default constructor is used to create objects from this class
	 * (default values).
	 */
	public Person() {
		super();	// call super class default constructor
		age = 17;
		name = "Dan";
	}
	
	/**
	 * constructor is used to create objects from this class
	 * (using supplied values).
	 */
	public Person(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Demonstrate use of this class
	 */
	public static void demo() {
		System.out.println(Person.class.getName() + ".demo()...");
		
		/**
		 * Use a class designed with Encapsulation (all data private, public methods)
		 */
		Person dan = new Person();
		System.out.println(dan.getName());	// name to stdout
		System.out.println(dan.getAge());	// age to stdout
				
		Person jim = new Person(37, "jim");
		System.out.println(jim.getName());	// name to stdout
		System.out.println(jim.getAge());	// age to stdout

		Person sally = new Person(27, "sally");
		System.out.println(sally.getName());	// name to stdout
		System.out.println(sally.getAge());	// age to stdout


		System.out.println(Person.class.getName() + ".demo()... done!");
	}

}
