package edu.neu.csye6200;

/**
 * Person class is used to model a person.
 * 
 * @author dpeters
 *
 */
public class SimplePubicPerson {
	/**
	 * Object instance data
	 * 1. Does not exist until object is created
	 * 2. Each created object has its own data
	 */
	public int age = 17;
	public String name = "Dan";
	
	/**
	 * NOTE:
	 * No constructors are specified.
	 * Java Compiler will supply a default constructor
	 * which initialize data to defaults (usually 0 or null)
	 */

}
