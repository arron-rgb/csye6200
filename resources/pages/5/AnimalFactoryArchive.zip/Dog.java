package edu.neu.csye6200;

public class Dog extends Animal {
	public void speak() {
		System.out.println("I am a dog.");
	}
}
