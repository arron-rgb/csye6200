package edu.neu.csye6200;

import java.awt.FlowLayout;
import java.awt.Frame;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * class SwingEx1
 * 
 * use a method to assemble a simple GUI using a JFrame and JButton.
 * 
 * @author https://www.javatpoint.com/java-swing
 *
 */
public class SwingEx1 {
	/**
	 * method assembles GUI: JFrame with non-functional JButton.
	 * 
	 * @param args
	 */
	public static void demo(String[] args) {
		//create a instance of class JFrame for our GUI window
		JFrame f = new JFrame();	
        
		//create instance of class JButton  
		JButton b=new JButton("i do nothing");
		b.setBounds(130,100,100, 40);//x axis, y axis, width, height  
		          
		f.add(b); //add button to Top Level Container Component JFrame  
		          
		f.setSize(400,500); // 400 width and 500 height  
		f.setLayout(null);  // NOT using a layout managers
		// exit and not merely hide on closing window
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true); // make the JFrame visible
		}

}
