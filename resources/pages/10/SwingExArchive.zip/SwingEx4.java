package edu.neu.csye6200;

import javax.swing.JButton;
import javax.swing.JFrame;

public class SwingEx4 extends JFrame implements Runnable { // inheriting JFrame

	public SwingEx4() {
	}

	private void createAndShowGUIU() {
			JButton b = new JButton("i do nothing");// create button
			b.setBounds(130, 100, 100, 40);
			
			add(b);// adding button on frame
			setSize(400, 500);
			setLayout(null);
			// exit and not merely hide on closing window
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setVisible(true);
		}

	@Override
	public void run() {
		createAndShowGUIU();
	}

	public static void demo(String[] args) {
		SwingEx4 obj = new SwingEx4();
		/**
		 * EITHER of the following
		 * (but not more than one: Swing is not thread safe)
		 * will start the Swing GUI
		 */
		Thread t = new Thread(obj);
//		Thread t = new Thread(new SwingEx4());
//		Thread t = new Thread(() -> { new SwingEx4().createAndShowGUIU(); });		

		t.start();
	}
}